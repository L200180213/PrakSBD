/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Herlangga
 */
public class Filter {
	public String num (String k)
	{
		k = k.replaceAll("[0-9]","");
		return k;
	}
	public String Alf (String k)
	{
		k = k.replaceAll("[a-zA-Z]","");
		return k;
	}
}
