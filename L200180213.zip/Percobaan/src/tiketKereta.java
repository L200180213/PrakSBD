/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | T;mplates
 * and open the template in the editor.
 */

/**
 *
 * @author Ghani Prasetia
 */
public abstract class tiketKereta implements Kereta{
    protected String namaKereta ;
    protected double harga;
    protected String jurusan ;
    protected String namaPenumpang;
    protected String jamAwalAkhir;
    
    
    abstract void setJenisTiket(String jenisTiket);
    abstract String getJenisTiket();
}
