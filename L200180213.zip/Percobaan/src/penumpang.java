/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ghani Prasetia
 */
public class penumpang {
    private String namaPenumpang;
    private String alamat;
    private String nomorTelfon;
    private int tanggalLahir;
    private int nomorIdentitas;
    
    void setNamaPenumpang(String namaPenumpang) {
        this.namaPenumpang = namaPenumpang;
    }
    
    String getNamaPenumpang() {
        return this.namaPenumpang;
    }
    
    void settanggalLahir(int tanggalLahir) {
        this.tanggalLahir = tanggalLahir;
    }
    
    int gettanggallahir() {
        return this.tanggalLahir;
    }
    
    void setnomerIdentitas(int nomorIdentitas) {
        this.nomorIdentitas = nomorIdentitas;
    }
    
    
    int getnomerIdentitas() {
        return this.nomorIdentitas;
    }
    
    void setAlamat(String alamat) {
        this.alamat = alamat;
    }
    
    String getAlamat() {
        return this.alamat;
    }
    
    void setnomorTelfon(String nomorTelfon) {
        this.nomorTelfon = nomorTelfon;
    }
    
    String getnomorTelfon() {
        return this.nomorTelfon;
    }
    
}
