/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ghani Prasetia
 */
public class eksekutif extends tiketKereta{
    private String jenisTiket;

    @Override
    public void setJenisTiket(String jenisTiket) {
        this.jenisTiket = jenisTiket;
    }

    @Override
    public String getJenisTiket() {
        return this.jenisTiket;
    }
    
    @Override
    public void setNamaKereta(String namaKereta) {
        this.namaKereta = namaKereta; 
    }

    @Override
    public String getNamaKereta() {
         return this.namaKereta;
    }
    
    @Override
    public void setHarga(double harga) {
        this.harga = harga+new Pajak().Pajak(harga);
    }

    @Override
    public double getHarga() {
        return this.harga;
    }

    @Override
    public void setJurusan(String jurusan) {
        this.jurusan = jurusan;
    }

    @Override
    public String getJurusan() {
       return this.jurusan;
    }  
		class Pajak {
		public double Pajak (double Harga){
			Harga=Harga/10;
			return Harga;
		}
	}
}
