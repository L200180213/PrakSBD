
import java.sql.*;

public class KeretaDB{
    private static final String USERNAME="root";
    private static final String PASSWORD=null;
    private static final String CONN_STRING=
            "jdbc:mysql://localhost/test";
        public static void main(String[]args){
            Connection ConnectMyObj=null;
            
            try{
                ConnectMyObj = DriverManager.getConnection(CONN_STRING, USERNAME, PASSWORD);
                System.out.println("Succesful");
                /**Statement stat = (Statement) ConnectMyObj.createStatement();**/
            }catch(SQLException e){
                System.err.println(e);
            }
        }
}
    
